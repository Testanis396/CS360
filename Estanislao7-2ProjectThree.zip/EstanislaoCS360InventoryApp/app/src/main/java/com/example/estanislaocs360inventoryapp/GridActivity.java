package com.example.estanislaocs360inventoryapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class GridActivity extends AppCompatActivity {

    Button addItem, editItems;
    String username;
    RecyclerView recyclerView;
    DBHelper DB;

    ArrayList<String> itemName, itemQuantity;
    CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.grid_layout);

        addItem = findViewById(R.id.buttonAddItem);
        editItems = findViewById(R.id.buttonEditItems);

        recyclerView = findViewById(R.id.recyclerView);

        Intent intent = getIntent();
        if (intent.hasExtra("username")) {
            username = intent.getStringExtra("username");
        }

        addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), CreateActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
            }
        });

        editItems.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), EditActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
            }
        });

        DB = new DBHelper(GridActivity.this);
        itemName = new ArrayList<>();
        itemQuantity = new ArrayList<>();
        getData();

        customAdapter = new CustomAdapter(GridActivity.this, itemName, itemQuantity);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(GridActivity.this));
    }

    void getData() {
        Cursor cursor = DB.getItems(username);
        if (cursor.getCount() == 0) {
            Toast.makeText(GridActivity.this, "No Items In Inventory.", Toast.LENGTH_SHORT).show();
        }
        else {
            // iterator that allows me to go through each item entry {username, item, quantity}
            while (cursor.moveToNext()) {
                itemName.add(cursor.getString(1));
                itemQuantity.add(cursor.getString(2));
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        itemName.clear();
        itemQuantity.clear();
        getData();
        customAdapter.notifyDataSetChanged();
    }
}