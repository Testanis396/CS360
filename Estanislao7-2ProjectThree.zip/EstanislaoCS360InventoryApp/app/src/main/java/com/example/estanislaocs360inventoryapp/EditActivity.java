package com.example.estanislaocs360inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditActivity extends AppCompatActivity {

    EditText searchName, newName, newQuantity;
    Button updateItem, deleteItem, getItem;
    String username;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_layout);

        updateItem = findViewById(R.id.buttonUpdateItem);
        deleteItem = findViewById(R.id.buttonDeleteItem);
        getItem = findViewById(R.id.buttonGetItem);
        searchName = findViewById(R.id.editTextSearchName);
        newName = findViewById(R.id.editTextNewName);
        newQuantity = findViewById(R.id.editTextNewQuantity);
        DB = new DBHelper(this);

        Intent intent = getIntent();
        if (intent.hasExtra("username")) {
            username = intent.getStringExtra("username");
        }

        getItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = searchName.getText().toString();

                if (name.equals("")) {
                    Toast.makeText(EditActivity.this, "Enter Item Name To Search.", Toast.LENGTH_SHORT).show();
                } else {
                    if (DB.checkItemExists(username, name) == false) {
                        Toast.makeText(EditActivity.this, "Item Does Not Exist.", Toast.LENGTH_SHORT).show();
                    } else {
                        Cursor cursor = DB.getItem(username, name);
                        // iterator that allows me to go through each item entry {username, item, quantity}
                        while (cursor.moveToNext()) {
                            newName.setText(cursor.getString(1));
                            newQuantity.setText(cursor.getString(2));
                        }
                        Toast.makeText(EditActivity.this, "Item Retrieved.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        updateItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String oldName = searchName.getText().toString();
                String name = newName.getText().toString();
                String quantityString = newQuantity.getText().toString();

                if(oldName.equals("") || name.equals("") || quantityString.equals("")) {
                    Toast.makeText(EditActivity.this, "Enter Old Item Name, New Name and Quantity.", Toast.LENGTH_SHORT).show();
                }
                else {
                    Integer quantity = Integer.parseInt(quantityString);
                    if (DB.checkItemExists(username, oldName) == false) {
                        Toast.makeText(EditActivity.this, "Item Does Not Exist. Edit Existing Item.", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        if (DB.updateItem(username, oldName, name, quantity) == true) {
                            Toast.makeText(EditActivity.this, "Item Updated.", Toast.LENGTH_SHORT).show();
                            onBackPressed();
                        }
                        else {
                            Toast.makeText(EditActivity.this, "Failed To Update Item. Check Fields And Try Again.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });

        deleteItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String oldName = searchName.getText().toString();
                String name = newName.getText().toString();

                if(name.equals("") || oldName.equals("")) {
                    Toast.makeText(EditActivity.this, "Enter Item Name In Both Name Fields To Delete", Toast.LENGTH_SHORT).show();
                }
                else {
                    if(!(name.equals(oldName))) {
                        Toast.makeText(EditActivity.this, "Enter Item Name In Both Name Fields To Delete", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        if (DB.checkItemExists(username, name) == false) {
                            Toast.makeText(EditActivity.this, "Item Does Not Exist. Delete Existing Item.", Toast.LENGTH_SHORT).show();
                        }
                        else {
                            if (DB.deleteItem(username, name) == true) {
                                Toast.makeText(EditActivity.this, "Item Deleted.", Toast.LENGTH_SHORT).show();
                                onBackPressed();
                            }
                            else {
                                Toast.makeText(EditActivity.this, "Failed To Delete Item. Check Fields And Try Again.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
            }
        });
    }
}