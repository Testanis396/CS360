package com.example.estanislaocs360inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateActivity extends AppCompatActivity {

    EditText itemName, itemQuantity;
    Button createItem;
    String username;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_layout);

        createItem = findViewById(R.id.buttonCreateItem);
        itemName = findViewById(R.id.editTextItemName);
        itemQuantity = findViewById(R.id.editTextItemQuantity);
        DB = new DBHelper(this);

        Intent intent = getIntent();
        if (intent.hasExtra("username")) {
            username = intent.getStringExtra("username");
        }

        createItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = itemName.getText().toString();
                String quantityString = itemQuantity.getText().toString();

                if(name.equals("") || quantityString.equals("")) {
                    Toast.makeText(CreateActivity.this, "Enter Item Name and Quantity.", Toast.LENGTH_SHORT).show();
                }
                else {
                    Integer quantity = Integer.parseInt(quantityString);
                    if (DB.checkItemExists(username, name) == true) {
                        Toast.makeText(CreateActivity.this, "Item Already In Database. Edit Item, Or Create New Item.", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        if (DB.addItem(username, name, quantity) == true) {
                            Toast.makeText(CreateActivity.this, "Item Added To Inventory.", Toast.LENGTH_SHORT).show();
                            onBackPressed();
                        }
                        else {
                            Toast.makeText(CreateActivity.this, "Failed To Create Item. Check Fields And Try Again.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
    });
    }
}