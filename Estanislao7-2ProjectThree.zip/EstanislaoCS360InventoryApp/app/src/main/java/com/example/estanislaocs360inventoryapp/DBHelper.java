package com.example.estanislaocs360inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DBNAME = "Inventory.db";

    public DBHelper(Context context) {
        super(context, "Inventory.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("CREATE TABLE users(username TEXT PRIMARY KEY, password TEXT)");
        MyDB.execSQL("CREATE TABLE inventory(username TEXT, item TEXT, quantity INTEGER, FOREIGN KEY(username) REFERENCES users(username))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        MyDB.execSQL("DROP TABLE IF EXISTS users");
        MyDB.execSQL("DROP TABLE IF EXISTS inventory");
    }

    public Boolean insertUser(String username, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = MyDB.insert("users", null, contentValues);
        // return true if successfully inserted new user into users table
        return result != -1;
    }

    public Boolean checkUserExists(String username){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("SELECT * FROM users WHERE username = ?", new String[] {username});
        // if username exists in users table return true
        return (cursor.getCount() > 0);
    }

    public Boolean authenticateUser(String username, String password) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("SELECT * FROM users WHERE username = ? AND password = ?", new String[]{username, password});
        // if username and password are correct return true
        return (cursor.getCount() > 0);
    }

    public Boolean addItem(String username, String item, Integer quantity){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("item", item);
        contentValues.put("quantity", quantity);
        long result = MyDB.insert("inventory", null, contentValues);
        // return true if successfully inserted new item into inventory table
        return result != -1;
    }

    public Boolean checkItemExists(String username, String item){
        SQLiteDatabase MyDB = this.getReadableDatabase();
        Cursor cursor = MyDB.rawQuery("SELECT * FROM inventory WHERE username = ? AND item = ?", new String[] {username, item});
        // if item exists in users' inventory return true
        return (cursor.getCount() > 0);
    }

    public Boolean updateItem(String username, String oldName, String item, Integer quantity){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("item", item);
        contentValues.put("quantity", quantity);
        long result = MyDB.update("inventory", contentValues, "username = ? AND item = ?", new String[] {username, oldName});
        // return true if successfully updated item in inventory table
        return result != -1;
    }

    public Boolean deleteItem(String username, String item){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        long result = MyDB.delete("inventory", "username = ? AND item = ?", new String[] {username, item});
        // return true if successfully deleted item from inventory table
        return result != -1;
    }

    public Cursor getItems(String username){
        SQLiteDatabase MyDB = this.getReadableDatabase();
        return MyDB.rawQuery("SELECT * FROM inventory WHERE username = ?", new String[] {username});
    }

    public Cursor getItem(String username, String item) {
        SQLiteDatabase MyDB = this.getReadableDatabase();
        return MyDB.rawQuery("SELECT * FROM inventory WHERE username = ? AND item = ?", new String[]{username, item});
    }
}
