package com.example.estanislaocs360inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/*
* CS 360 7-2 Project Three
*
* Tomas Estanislao
*
* 3/1/24
*
* I used the following videos as resources for my project:
* https://www.youtube.com/watch?v=VQKq9RHMS_0
* https://www.youtube.com/watch?v=8obgNNlj3Eo
* https://www.youtube.com/watch?v=-9EoMCVx2lM&t=918s
* https://stackoverflow.com/questions/30502515/refresh-recyclerview-from-another-activity
*
* I used these to figure out how to get the local SQLite database set up,
* how to perform CRUD operations,
* how to use intents,
* how to implement recycler view,
* how to refresh recycler view.
*
* I have previously taken a databases class on MySQL.
*
* I didn't think that I would need an item ID for each item.
* But by the time I started to implement updating and deleting,
* I realized that I should have used item IDs' for quick query's
* So I stuck with my original idea,
* you have to type the name of the item you want to modify.
* I also was thinking of adding buttons per card instead,
* but it turned out to be a bit difficult.
*
 */

public class MainActivity extends AppCompatActivity {

    EditText username, password;
    Button signIn, createAccount;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        signIn = findViewById(R.id.buttonSignIn);
        createAccount = findViewById(R.id.buttonCreateAccount);
        username = findViewById(R.id.editTextUsername);
        password = findViewById(R.id.editTextPassword);
        DB = new DBHelper(this);

        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                if(user.equals("") || pass.equals("")) {
                    Toast.makeText(MainActivity.this, "Enter Username and Password.", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (DB.checkUserExists(user) == false) {
                        Toast.makeText(MainActivity.this, "User Does Not Exist. Create Account.", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        if (DB.authenticateUser(user, pass) == true) {
                            Toast.makeText(MainActivity.this, "User Authenticated. Signing In.", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), GridActivity.class);
                            intent.putExtra("username", user);
                            startActivity(intent);
                        }
                        else {
                            Toast.makeText(MainActivity.this, "Incorrect Password. Retry.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });

        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                if(user.equals("") || pass.equals("")) {
                    Toast.makeText(MainActivity.this, "Enter Username And Password.", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (DB.checkUserExists(user) == true) {
                        Toast.makeText(MainActivity.this, "User Already Exists. Sign In.", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        if (DB.insertUser(user, pass) == true) {
                            Toast.makeText(MainActivity.this, "New User Created. Signing In.", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), GridActivity.class);
                            intent.putExtra("username", user);
                            startActivity(intent);
                        }
                        else {
                            Toast.makeText(MainActivity.this, "Failed To Create New User. Check Fields.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
    }
}